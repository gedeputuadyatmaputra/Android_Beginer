package com.dicoding.marvel_android_sederhana

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class About : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        supportActionBar?.apply {
            title = getString(R.string.about_profile)
        }
    }
}