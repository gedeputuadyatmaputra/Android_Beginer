package com.dicoding.marvel_android_sederhana

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Character(
    val name: String,
    val description: String,
    val photo: Int,
    val detail: String,
    val actor: String
): Parcelable
